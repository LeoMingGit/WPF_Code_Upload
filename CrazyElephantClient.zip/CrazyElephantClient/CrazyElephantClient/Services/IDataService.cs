﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CrazyElephantClient.Models;

namespace CrazyElephantClient.Services
{
    public interface IDataService
    {
        List<Dish> GetAllDishes();
    }
}
