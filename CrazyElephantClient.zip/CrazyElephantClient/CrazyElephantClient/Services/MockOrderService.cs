﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrazyElephantClient.Services
{
    class MockOrderService : IOrderService
    {
        string path = System.Reflection.Assembly.GetExecutingAssembly().Location;
        string FolderPath = System.AppDomain.CurrentDomain.BaseDirectory;
        public void PlaceOrder(List<string> dishes)
            
        {
            Console.WriteLine(FolderPath);
            System.IO.File.WriteAllLines(FolderPath, dishes.ToArray());
        }
    }
}
